SOFC Thermo-Mechanical Dataset Package
=======================================

IMPORTANT DISCLAIMER
--------------------
ALL DATA IN THIS PACKAGE IS SYNTHETIC/ILLUSTRATIVE AND FOR EDUCATIONAL PURPOSES ONLY

- All CSV files contain SYNTHETIC DATA generated based on published literature ranges
- This data is NOT experimental data from actual SOFC measurements
- DO NOT use this data as ground truth for research or engineering without independent verification
- The data demonstrates typical ranges and trends for SOFC thermo-mechanical investigations

Dataset Contents
----------------
This ZIP archive contains 15 CSV files with temperature-dependent properties, 
creep behavior, thermal cycling degradation, and FEM inputs for SOFC materials.

Files included:
01_thermal_properties.csv           - Temperature-dependent thermal properties
02_mechanical_properties.csv        - Elastic modulus, strength, toughness
03_creep_parameters_norton.csv      - Norton power-law creep parameters
04_creep_curves_NiYSZ.csv          - Simulated creep strain vs time
05_CTE_mismatch_thermal_stress.csv - CTE and interfacial thermal stress
06_polarization_curves.csv         - I-V and power density curves
07_thermal_cycling_degradation.csv - Performance over thermal cycles
08_strain_hardening_FEM_input.csv  - Time-hardening creep for FEM
09_temperature_distribution.csv    - 2D temperature field on cell
10_stress_evolution_thermal_cycle.csv - Stress during heating-dwell-cooling
11_cell_geometry.csv               - Layer dimensions
12_operating_conditions.csv        - Test matrix scenarios
13_residual_stress.csv             - Post-sintering residual stress
14_redox_cycling.csv               - Chemical expansion during redox
15_FEM_input_summary.csv          - Quick-reference property table

Materials Covered
-----------------
- 8YSZ (Electrolyte)
- GDC (Buffer layer)
- Ni-YSZ (Anode)
- LSCF (Cathode)
- LSM (Cathode)
- Crofer 22 APU (Interconnect)

Data Format
-----------
All CSV files include:
- Comment header lines (starting with #) stating synthetic nature
- Column headers with units
- Data in SI or explicitly stated units

For More Information
--------------------
See the full repository at: https://github.com/georgegershom22-oss/george
- Complete documentation in README.md
- Python visualization scripts in scripts/ directory
- Links to real open-access SOFC datasets in open_data_sources.md

Generated: 2026-02-22 14:06:55

Version: 1.0
